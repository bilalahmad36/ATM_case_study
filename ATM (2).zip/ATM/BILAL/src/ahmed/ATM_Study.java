
package ahmed;

public class ATM_Study {
    public static void main(String[] args) {
       ATM theATM = new ATM(); 
       theATM.run();
    }
    
}
